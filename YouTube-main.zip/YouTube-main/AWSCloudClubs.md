![Copy of Copy of Copy of Azure](https://user-images.githubusercontent.com/66474973/217035092-a84513d2-1dd5-4135-b6e3-7babb19d4bd2.png)



Are you:

* Enrolled in a College or University or learning on your own
* Aged between 18-28
* Interested in creating peer-to-peer learning experiences for your local student community
* Curious about skilling up in AWS technology
* Looking to build your career and network

If so, please join an AWS Cloud Club near you. We are looking for stellar Cloud Club Captains to lead these clubs in 
Australia, Bangladesh, France, India, Ireland, Mexico, Nigeria, Pakistan, United Kingdom, and the United States. 

What’s in it for you and your communities? Based on your activities, earn perks such as AWS credits, certification vouchers, swag, bespoke learning and networking experiences, and more. We will work with you to make your Club awesome!

Ready? Set? Go! Please fill in the AWS Cloud Club Captain Application Form. This form is opening now and will close on Feb 19th. If your region isn’t included in the launch list, please fill in the Cloud Clubs interest list to express your interest in founding or joining a future club.


